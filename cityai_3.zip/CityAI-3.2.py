from flask import Flask, request, render_template, redirect, url_for, send_file, jsonify
import openai
import pdfplumber
import pandas as pd
import io

app = Flask(__name__)

# Set your OpenAI API key
openai.api_key = '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'  # Replace with your actual OpenAI API key

# Extract text from PDF using pdfplumber
def extract_text_from_pdf(file):
    extracted_text = ''
    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                extracted_text += text + '\n'
    return extracted_text

# Chunking text for processing with GPT
def chunk_text(text, max_chunk_size=2000):
    chunks = []
    for i in range(0, len(text), max_chunk_size):
        chunks.append(text[i:i + max_chunk_size])
    return chunks

# Function to extract specific data (e.g., total population) and format as CSV
def extract_specific_data_as_csv(extracted_text, query):
    chunks = chunk_text(extracted_text)
    full_csv = ""

    for chunk in chunks:
        prompt = f"""
        Extract the {query} from the provided text and format it as a CSV. The CSV should have columns for Block, Male Population, Female Population, and Total Population.

        Extracted Text:
        {chunk}
        """
        
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an assistant trained to extract tabular data."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=2000,
            temperature=0
        )
        full_csv += response['choices'][0]['message']['content'] + "\n"
    
    return full_csv

# Home route to display the combined upload, chat, and download interface
@app.route('/')
def index():
    return render_template('combined_ui2.html')

# Route to handle file upload and store text for chat
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    
    extracted_text = extract_text_from_pdf(file)
    # Save extracted text in session or temporary storage
    app.config['EXTRACTED_TEXT'] = extracted_text

    return render_template('combined_ui2.html', message="PDF uploaded successfully. You can now chat with the document or extract data!")

# Route to extract specific data as CSV
@app.route('/extract_csv', methods=['POST'])
def extract_csv():
    query = request.form['query']  # Expecting something like "total population"
    extracted_text = app.config.get('EXTRACTED_TEXT', '')
    if not extracted_text:
        return "Error: No PDF text found. Please upload a PDF first."

    # Extract specific data and format as CSV
    extracted_csv = extract_specific_data_as_csv(extracted_text, query)
    data_df = pd.read_csv(io.StringIO(extracted_csv))

    # Save the DataFrame as a CSV file in memory
    output = io.BytesIO()
    data_df.to_csv(output, index=False)
    output.seek(0)

    # Send the CSV file as a downloadable response
    return send_file(output, as_attachment=True, download_name=f'{query}_data.csv', mimetype='text/csv')

# Start the Flask app
if __name__ == '__main__':
    port = 5001
    print(f"Starting Flask app. Access the application at: http://127.0.0.1:{port}")
    app.run(debug=True, host='127.0.0.1', port=port)
