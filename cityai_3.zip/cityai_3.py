from flask import Flask, request, render_template, redirect, url_for, send_file, jsonify
import openai
import pdfplumber
import pandas as pd
import geopandas as gpd
import io

app = Flask(__name__)

# Set your OpenAI API key
openai.api_key = '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'  # Replace with your actual OpenAI API key

# Extract text from PDF using pdfplumber
def extract_text_from_pdf(file):
    extracted_text = ''
    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            extracted_text += text + '\n'
    return extracted_text

# Function to chat with GPT using extracted PDF text
def chat_with_pdf(extracted_text, query):
    prompt = f"""
    You have extracted data from a PDF document. Your task is to answer the following query based on the extracted data. 

    Query: "{query}"

    Extracted Data:
    {extracted_text[:2000]}  # Limiting to 2000 characters to avoid exceeding token limits
    """
    
    response = openai.ChatCompletion.create(
        model="gpt-4",  # Use "gpt-4" if available
        messages=[
            {"role": "system", "content": "You are an assistant trained to extract information from documents."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=1500,
        temperature=0
    )
    answer = response['choices'][0]['message']['content']
    return answer

# Function to extract block-wise data as CSV
def extract_block_data_as_csv(extracted_text):
    prompt = f"""
    Extract block-specific data from the provided text, including relevant demographic or resource information, and format it as a CSV with the columns: Block, Population, etc.

    Extracted Text:
    {extracted_text[:2000]}  # Limiting to 2000 characters for processing
    """
    
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an assistant trained to extract tabular data."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=1500,
        temperature=0
    )
    csv_text = response['choices'][0]['message']['content']
    return csv_text

# Function to match block-wise data with GeoJSON
def extract_and_match_geojson(extracted_text, geojson_data):
    prompt = f"""
    Extract block-specific data from the provided text, including relevant demographic or resource information. Ensure the output is formatted as a CSV with block-specific columns.

    Extracted Text:
    {extracted_text[:2000]}  # Limiting to 2000 characters for processing
    """
    
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an assistant trained to extract and match data."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=1500,
        temperature=0
    )
    csv_text = response['choices'][0]['message']['content']

    # Load extracted CSV data into a DataFrame
    block_df = pd.read_csv(io.StringIO(csv_text))

    # Print DataFrame columns for debugging
    print("Extracted DataFrame Columns:", block_df.columns.tolist())

    # Load GeoJSON data into a GeoDataFrame
    gdf = gpd.read_file(io.StringIO(geojson_data))

    # Print GeoDataFrame columns for debugging
    print("GeoDataFrame Columns:", gdf.columns.tolist())

    # Ensure required columns are present for merging
    if 'Block' not in block_df.columns:
        return "Error: 'Block' column not found in extracted data."

    if 'Name_2' not in gdf.columns:
        return "Error: 'Name_2' column not found in GeoJSON data."

    # Merge GeoDataFrame with extracted data, matching 'Name_3' with 'Block'
    gdf['matched_data'] = gdf['Name_2'].map(block_df.set_index('Block').to_dict(orient='index')).apply(lambda x: x if pd.notnull(x) else {})

    # Convert matched GeoDataFrame back to GeoJSON
    geojson_output = gdf.to_json()
    return geojson_output

# Home route to display the combined upload, chat, and download interface
@app.route('/')
def index():
    return render_template('combined_ui2.html')

# Route to handle file upload and store text for chat
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    
    extracted_text = extract_text_from_pdf(file)
    # Save extracted text in session or temporary storage
    app.config['EXTRACTED_TEXT'] = extracted_text

    return render_template('combined_ui2.html', message="PDF uploaded successfully. You can now chat with the document or extract data!")

# Route to handle chat queries
@app.route('/chat', methods=['POST'])
def chat():
    query = request.form['query']
    extracted_text = app.config.get('EXTRACTED_TEXT', '')

    if not extracted_text:
        return jsonify({'answer': 'No PDF text found. Please upload a PDF first.'})

    # Get the answer from GPT
    answer = chat_with_pdf(extracted_text, query)
    return jsonify({'answer': answer})

# Route to extract population data as CSV
@app.route('/extract_csv', methods=['POST'])
def extract_csv():
    extracted_text = app.config.get('EXTRACTED_TEXT', '')
    if not extracted_text:
        return "Error: No PDF text found. Please upload a PDF first."

    # Extract block-specific data and format as CSV
    extracted_csv = extract_block_data_as_csv(extracted_text)
    data_df = pd.read_csv(io.StringIO(extracted_csv))

    # Save the DataFrame as a CSV file in memory
    output = io.BytesIO()
    data_df.to_csv(output, index=False)
    output.seek(0)

    # Send the CSV file as a downloadable response
    return send_file(output, as_attachment=True, download_name='extracted_data.csv', mimetype='text/csv')

# Route to handle GeoJSON upload, match data, and output matched GeoJSON
@app.route('/upload_geojson', methods=['POST'])
def upload_geojson():
    if 'geojson_file' not in request.files:
        return redirect(request.url)
    
    geojson_file = request.files['geojson_file']
    extracted_text = app.config.get('EXTRACTED_TEXT', '')
    
    if geojson_file.filename == '' or not extracted_text:
        return "Error: Please upload both PDF and GeoJSON files."

    geojson_data = geojson_file.read().decode('utf-8')
    matched_geojson = extract_and_match_geojson(extracted_text, geojson_data)

    # Return matched GeoJSON as downloadable file
    return send_file(
        io.BytesIO(matched_geojson.encode('utf-8')),
        as_attachment=True,
        download_name='matched_data.geojson',
        mimetype='application/json'
    )

# Start the Flask app
if __name__ == '__main__':
    port = 5001
    print(f"Starting Flask app. Access the application at: http://127.0.0.1:{port}")
    app.run(debug=True, host='127.0.0.1', port=port)
